<?php
     include('config/connect.php');

    if(isset ($_POST['btn'])){
       $tenluat = $_POST['tenluat'];
       $banhanh = $_POST['banhanh'];
       $hieuluc = $_POST['hieuluc'];
       
       $sql = "INSERT INTO luat (ten_luat, ban_hanh, hieu_luc )
       VALUES ('$tenluat', '$banhanh','$hieuluc') ";
        mysqli_query($conn, $sql);

       

        header("location: law.php");
    }
    
       
?>
