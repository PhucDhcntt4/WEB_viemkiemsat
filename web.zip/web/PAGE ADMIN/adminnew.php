<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Admin</title>
    <link rel="stylesheet" href="css/bang.css">
</head>
<body>
<div class="container">  
<button ><a href="add_new.php">Thêm tin </a></button>
</div>
<form action="" method="post">
    <input type="text" name="noidung">
    <button type="submit" name="btn"> Tìm Kiếm </button>
</form>

<?php
    
    $noidung = "noidung";

    if(isset($_POST['btn'])){
        $noidung = $_POST['noidung'];   
        
    }
    
?>


   
    <table class="styled-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tiêu Đề</th>
            <th>Nội dung</th>
            <th>image</th>
            <th>Ngày đăng</th>
            <th></th>
            <th></th>
        </tr>
    </thead>

    <tbody>
        <?php 
            include "connect.php";

            $sql = "SELECT * FROM news";
            $result = mysqli_query($conn, $sql);

            while($row = mysqli_fetch_array($result)){
        ?><br>
            <tr>
                <td><?php echo $row['id_tintuc']?></td>
                <td><?php echo $row['tieu_de']?></td>
                <td><?php echo $row['noi_dung']?></td>
                <td><img width="30" height="40" src="image/news/<?php echo $row['image']?>" alt="">  </td>
                <td><?php echo $row['ngay_dang']?></td>
                <td><span><a href="delete_news.php?this_id=<?php echo $row['id_tintuc']?>">xóa</a></span></td>
                <td><span><a href="edit_news.php?this_id=<?php echo $row['id_tintuc']?>">sửa</a></span></td>
            </tr>
        <?php }?>        
    </tbody>
 </table>

</body>

</html>