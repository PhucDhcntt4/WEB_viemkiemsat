<?php 
    include"config/connect.php";    

    $this_id = $_GET['this_id'];


    $sql = "SELECT * FROM luat WHERE id_luat = ".$this_id ;

    $query = mysqli_query($conn, $sql);

    $row = mysqli_fetch_assoc($query);

    if(isset($_POST['btn']) ){

        $tenluat = $_POST['tenluat'];
        $banhanh = $_POST['banhanh'];
        $hieuluc = $_POST['hieuluc'];

        $sql = "UPDATE luat SET ten_luat='$tenluat', ban_hanh = '$banhanh',
        hieu_luc = '$$hieuluc' WHERE id_luat =".$this_id;

        mysqli_query($conn, $sql);

       
       
        header("location: law.php");
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="css/edit.css">
    <title>Add Product</title>
   
</head>
<body>
    <table>
    <div class="container">
        <form  method="post" enctype="multipart/form-data">
            <label >Tên Luật </label>
            <input type="text" name="tenluat" value="<?php echo $row['ten_luat']; ?>" required>
            
            <label >Ngày Ban Hành </label>
            <input type="date"  name="banhanh" rows="4" value="<?php echo $row['ban_hanh']; ?>"required></input>

            <label > Hiệu Lực </label>
            <input type="date" name="hieuluc" value="<?php echo $row['hieu_luc']; ?>">


            
            <button type="submit" name="btn">Sửa đổi</button> <a href="edit_luat.php"><button type="su"
                            class="do">Nhập lại</button></a>
            
        </form>
    </div></table>
</body>
</html>

