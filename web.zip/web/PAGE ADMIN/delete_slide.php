<?php
    include"config/connect.php"; 
    
    $this_id = $_GET['this_id'];

    echo $this_id;

    $sql = "DELETE FROM slides WHERE id ='$this_id' ";

    mysqli_query($conn, $sql);

    header("location: Slide.php");
?>

