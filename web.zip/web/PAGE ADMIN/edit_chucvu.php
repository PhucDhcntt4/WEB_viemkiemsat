<?php 
    include"config/connect.php";    

    $this_id = $_GET['this_id'];


    $sql = "SELECT * FROM chuc_vu WHERE Ma_cong_chuc = ".$this_id ;

    $query = mysqli_query($conn, $sql);

    $row = mysqli_fetch_assoc($query);

    if(isset($_POST['btn']) ){
        $name = $_POST['name'];
        $chucvu = $_POST['chucvu'];

        $sql = "UPDATE chuc_vu SET name ='$name', chucvu = '$chucvu' WHERE Ma_cong_chuc =".$this_id;

        mysqli_query($conn, $sql);

       
       
        header("location: indexadmin.php");
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="css/edit.css">
    <title></title>
   
</head>
<body>
    <table>
    <div class="container">
        <form  method="post" enctype="multipart/form-data">
            <label >TÊN</label>
            <input type="text" name="name" value="<?php echo $row['name']; ?>" required>


            <label > Chức vụ </label>
            <input type="text" name="chucvu" value="<?php echo $row['chucvu']; ?>">


            
            <button type="submit" name="btn">Sửa đổi</button> <a href="edit_chucvu.php"><button type="su"
                            class="do">Nhập lại</button></a>
            
        </form>
    </div></table>
</body>
</html>

