<?php
    include"config/connect.php"; 
    
    $this_id = $_GET['this_id'];

    echo $this_id;

    $sql = "DELETE FROM vanban WHERE id_van_ban ='$this_id' ";

    mysqli_query($conn, $sql);

    header("location: van_ban.php");
?>

