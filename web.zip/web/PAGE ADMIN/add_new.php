<?php
     include('config/connect.php');

    if(isset ($_POST['btn'])){
       $tieude = $_POST['tieude'];
       $noidung = $_POST['noidung'];
       $image = $_FILES['image']['name'];
       $image_tmp_name = $_FILES['image']['tmp_name'];
       $ngaydang = $_POST['ngaydang'];
       
       $sql = "INSERT INTO news (tieu_de, noi_dung, image, ngay_dang)
       VALUES ('$tieude', '$noidung','$image', '$ngaydang') ";
        mysqli_query($conn, $sql);

        move_uploaded_file($image_tmp_name, 'image/news/'.$image );

        header("location:news.php");
    }
    
       
?>
