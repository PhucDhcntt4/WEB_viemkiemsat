<?php
    include"connect.php";

    if(isset ($_POST['btn'])){
       $tieude = $_POST['tieude'];
       $noidung = $_POST['noidung'];
       $image = $_FILES['image']['name'];
       $image_tmp_name = $_FILES['image']['tmp_name'];
       $ngaydang = $_POST['ngaydang'];
       
       $sql = "INSERT INTO news (tieu_de, noi_dung, image, ngay_dang)
       VALUES ('$tieude', '$noidung','$image', '$ngaydang') ";
        mysqli_query($conn, $sql);

        move_uploaded_file($image_tmp_name, 'image/news/'.$image );

        header("location: adminnew.php");
    }
    
       
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="css/bang.css">
    <title>Add Product</title>
   
</head>
<body>
    <div class="container">
        <h2>Add Product</h2>
        <form action="add_new.php" method="post" enctype="multipart/form-data">
            <label >Tiêu Đề </label>
            <input type="text" name="tieude" required>
            
            <label >Nội Dung </label>
            <input type="file" name="noidung" rows="4" required></input>

            <label > Image </label>
            <input type="file" name="image" required>

            <label > Ngày Đăng</label>
            <input type="date" name="ngaydang">

            <button type="submit" name="btn">Thêm</button> <a href="add_new.php"><button type="submit" class="do">Nhập lại</button></a>
            
        </form>
    </div>
</body>
</html>
