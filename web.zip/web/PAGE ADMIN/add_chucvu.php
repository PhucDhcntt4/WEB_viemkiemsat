<?php
     include('config/connect.php');

    if(isset ($_POST['btn'])){
      
       $name = $_POST['name'];
       $chucvu = $_POST['chucvu'];
       
       $sql = "INSERT INTO chuc_vu (name, chucvu)
       VALUES ('$name', '$chucvu') ";
        mysqli_query($conn, $sql);

      

        header("location:indexadmin.php");
    }
    
       
?>
