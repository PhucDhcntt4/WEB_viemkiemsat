<?php 
    include"config/connect.php";    

    $this_id = $_GET['this_id'];


    $sql = "SELECT * FROM slides WHERE id = ".$this_id ;

    $query = mysqli_query($conn, $sql);

    $row = mysqli_fetch_assoc($query);

    if(isset($_POST['btn']) ){

        $title = $_POST['title'];
        $image = $_FILES['image']['name'];
        $image_tmp_name = $_FILES['image']['tmp_name'];
        $status = $_POST['status'];

        $sql = "UPDATE slides SET title ='$title',
         image ='$image', status = '$status' WHERE id =".$this_id;

        mysqli_query($conn, $sql);

        move_uploaded_file($image_tmp_name, 'PAGE USER/images/slide/'.$image );
       
        header("location: Slide.php");
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="css/edit.css">

   
</head>
<body>
    <table>
    <div class="container">
    <h2><?php  echo $row['title']; ?> </h2>
        <form  method="post" enctype="multipart/form-data">
            <label >Tiêu Đề </label>
            <input type="text" name="title" value="<?php echo $row['title']; ?>" required>

            <label > Image </label>
            <span><img src="PAGE USER/images/slide/<?php echo $row['image']; ?>" alt=""></span>
            <input type="file" name="image"  required>

            <label >Status </label>
            <select name="status">
                <option value="<?php echo $row['status']?>"></option>
                <option value="1">1</option>
                <option value="0">0</option>
            </select>


            
            <button type="submit" name="btn">Sửa đổi</button> <a href="edit_slide.php"><button type="su"
                            class="do">Nhập lại</button></a>
            
        </form>
    </div></table>
</body>
</html>

