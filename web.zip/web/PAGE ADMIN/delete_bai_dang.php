<?php
    include"config/connect.php"; 
    
    $this_id = $_GET['this_id'];

    echo $this_id;

    $sql = "DELETE FROM bai_dang WHERE id ='$this_id' ";

    mysqli_query($conn, $sql);

    header("location: bai_dang.php");
?>

