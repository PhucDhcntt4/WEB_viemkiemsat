<?php 
    include"config/connect.php";    

    $this_id = $_GET['this_id'];


    $sql = "SELECT * FROM doanthe WHERE id_doan_the = ".$this_id ;

    $query = mysqli_query($conn, $sql);

    $row = mysqli_fetch_assoc($query);

    if(isset($_POST['btn']) ){
        $type = $_POST['type'];
        $name = $_POST['name'];

        $sql = "UPDATE doanthe SET type ='$type', name = '$name' WHERE id_doan_the =".$this_id;

        mysqli_query($conn, $sql);

       
       
        header("location: Doan_the.php");
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="css/edit.css">
    <title></title>
   
</head>
<body>
    <table>
    <div class="container">
        <form  method="post" enctype="multipart/form-data">
            <label >Type</label>
            <select name="type">
                <option value="<?php  echo $row['type']?>"></option>
                <option value="Đoàn Thanh Niên">Đoàn thanh niên</option>
                <option value="Công Đoàn">Công Đoàn</option>
            </select>

            <label > Tên </label>
            <input type="text" name="name" value="<?php echo $row['name']; ?>">


            
            <button type="submit" name="btn">Sửa đổi</button> <a href="edit_doanthe.php"><button type="su"
                            class="do">Nhập lại</button></a>
            
        </form>
    </div></table>
</body>
</html>

