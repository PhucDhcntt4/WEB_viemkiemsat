<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="image/news/vienkiemsat.jpg">

    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>]
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bang.css">

    <title>Admin</title>
</head>

<body>



    <section id="sidebar">
        <a href="indexadmin.php" class="brand">
        <i class='bx bx-user'></i>
            <span class="text">Admin</span>
        </a>
        <ul class="side-menu top">
        <li >
				<a href="Slide.php">
				<i class='bx bx-slideshow'></i>
					<span class="text">Slides</span>
				</a>
			</li>
			<li >
				<a href="news.php">
				<i class='bx bx-news'></i>
					<span class=text">Tin Tức</span>
				</a>
			</li>
			<li class="active">
				<a href="law.php">
				<i class='bx bx-receipt'></i>
					<span class="text">Luật</span>
				</a>
			</li>
			<li>
				<a href="Doan_the.php">
				<i class='bx bx-group'></i>
					<span class="text">Đoàn Thể</span>
				</a>
			</li>
			<li>
				<a href="van_ban.php">
				<i class='bx bx-notepad'></i>
					<span class="text">Văn Bản</span>
				</a>
			</li>
			<li>
				<a href="bai_dang.php">
				<i class='bx bx-window-open'></i>
					<span class="text">Bài Đăng</span>
				</a>
			</li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="logout.php" class="logout">
                    <i class='bx bxs-log-out-circle'></i>
                    <span class="text">Logout</span>
                </a>
            </li>
        </ul>
    </section>





    <section id="content">

        <nav>
            <i class='bx bx-menu'></i>
            <a href="PAGE USER/index.html" class="nav-link">Trang Web </a>
            <form action="#">
                <i class='bx bxs-home'></i>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="notification">
                <i class='bx bxs-bell'></i>
                <span class="num"></span>
            </a>
            <a href="#" class="profile">
                <img src="image/news/admin.jpg">
            </a>
        </nav>

        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Trang Quản Trị </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a class="active" href="#">Trang Quản Trị </a>
                        </li>
                        <li><i class='bx bx-chevron-right'></i></li>
                        <li>
                            <a class="active" href="#">Luật</a>
                        </li>
                    </ul>
                </div>

                <span type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">
                    Thêm mới
                </span>

                </a>
            </div>

            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Luật</h3>

                        <nav>

                            <form method="post">
                                <div class="form-input">
                                    <input type="search" placeholder="Search..." name="noidung">
                                    <button type="" class="search-btn" name="btn"><i class='bx bx-search'></i></button>
                                </div>
                            </form>
                            <?php
							
							$noidung = "noidung";

							if(isset($_POST['btn'])){
								$noidung = $_POST['noidung'];    
							}
							
						?>

                            <?php 
    include("connect.php");

    $sql ="SELECT * FROM luat WHERE ten_luat LIKE '%$noidung%' ";

    $result = mysqli_query($conn, $sql);

    while( $row = mysqli_fetch_array($result) )
    {?>
                        </nav>
                        <!-- <i class='bx bx-filter' ></i> -->
                    </div>
                    <h1>Kết Quả Tìm Kiếm </h1>
                    <table>
                        <thead>
                            <tr>
                                <th>ID_Luat</th>
                                <th>Tên</th>
                                <th>Ngày Ban hành </th>
                                <th>Hiệu Lực</th>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 


				
					$result = mysqli_query($conn, $sql);

							while($row = mysqli_fetch_array($result)){
					?><br>
                            <tr>
                                <td><?php echo $row['id_luat']?></td>
                                <td><?php echo $row['ten_luat']?></td>
                                <td><?php echo $row['ban_hanh']?></td>
                                <td><?php echo $row['hieu_luc']?></td>
                                <td>
                                    <a href="delete_news.php?this_id=<?php echo $row['id_luat']?>">
                                        <i class='bx bxs-message-square-x'></td></a></td>
                                <td>
                                    <a href="edit_news.php?this_id=<?php echo $row['id_luat']?>"><i
                                                class='bx bxs-edit-alt'></i> </a>
                                </td>
                            </tr>
                            <?php }?>
                            <?php }?>
                </div>
                <table>
                    <thead>
                        <tr>
                                <th>ID_Luat</th>
                                <th>Tên</th>
                                <th>Ngày Ban hành </th>
                                <th>Hiệu Lực</th>
                                <th></th>
                                <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 

					include "connect.php";
					$sql = "SELECT * FROM luat ";

					$result = mysqli_query($conn, $sql);
					
					while($row = mysqli_fetch_array($result)){
					?><br>
                         <tr>
                                <td><?php echo $row['id_luat']?></td>
                                <td><?php echo $row['ten_luat']?></td>
                                <td><?php echo $row['ban_hanh']?></td>
                                <td><?php echo $row['hieu_luc']?></td>
                                <td>
                                    <a href="delete_news.php?this_id=<?php echo $row['id_luat']?>">
                                        <i class='bx bxs-message-square-x'></td></a></td>
                                <td>
                                    <a href="edit_news.php?this_id=<?php echo $row['id_luat']?>"><i
                                                class='bx bxs-edit-alt'></i> </a>
                                </td>
                            </tr>
                        <?php }?>
                    </tbody>

                </table>
            </div>
            </div>
        </main>

    </section>



    <script src="js/script.js"></script>
</body>

</html>

<div class="modal" id="myModal">
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Modal Heading</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                <form action="add_new.php" method="post" enctype="multipart/form-data">
                    <label>Tên Luật </label>
                    <input type="text" name="tieude" required>

                    <label>Ngày Ban Hành </label>
                    <input type="date" name="ngaybanhanh" rows="4" required></input>


                    <label> Ngày Có Hiệu Lực</label>
                    <input type="date" name="ngayhieuluc">

                    <button type="submit" name="btn">Thêm</button> <a href="add_new.php"><button type="su"
                            class="do">Nhập lại</button></a>

                </form>
            </div>

            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>