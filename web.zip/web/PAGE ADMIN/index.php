
    <?php
            session_start();

            if(!isset($_SESSION['mySession'])){

                header("location: login.php");
            }

        
    ?>
  
</form>

<h1>
    Trang chủ 
<a href="logout.php">

    <button type="submit" name="dangxuat"> Đăng xuất </button>

</a>
</h1>

<!-- chức năng tìm kiếm  -->
<br>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search</title>
    <link rel="stylesheet" href="css/bang.css">
</head>
<body>
    <div class="container">
        <h2>Search</h2>
        <form action="search.php" method="post">
            <input type="text" name="noidung" placeholder="Enter your search term">
            <button type="submit" name="btn">Search</button>
        </form>
        <div class="search-results">
            <?php include('search.php'); ?>
        </div>
    </div>
</body>
</html>



<!-- chức năng thống kê  -->
<?php 
    include("connect.php");

    $sql ="SELECT * FROM news WHERE tieu_de LIKE '%$noidung%' ";

    $result = mysqli_query($conn, $sql);

    while( $row = mysqli_fetch_array($result) )
    {?>
		<br>
       <?php echo $row['tieu_de']; ?><br>

   <?php }?>
    

   <?php 
    $fp = 'image/news/dem.txt';

    $fo = fopen($fp, 'r');
    $count = fread($fo, filesize($fp));
    $count ++;
    $fc = fclose($fo);
    $fo = fopen($fp, 'w');
    $fw = fwrite($fo, $count);
    $fc = fclose($fo);

    
// Dữ liệu cần gửi đi
$data = $count;

?>
