<?php 
    include"config/connect.php";    

    $this_id = $_GET['this_id'];


    $sql = "SELECT * FROM bai_dang WHERE id = ".$this_id ;

    $query = mysqli_query($conn, $sql);

    $row = mysqli_fetch_assoc($query);

    if(isset($_POST['btn']) ){

        $tieude = $_POST['tieude'];
        $tintuc = $_POST['tintuc'];
        $ngaydang = $_POST['ngaydang'];

        $sql = "UPDATE bai_dang SET tieu_de='$tieude', id_tintuc = '$tintuc',
         ngay_dang = '$ngaydang' WHERE id =".$this_id;

        mysqli_query($conn, $sql);

       
       
        header("location: bai_dang.php");
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="css/edit.css">
    <title>Add Product</title>
   
</head>
<body>
    <table>
    <div class="container">
    <h2><?php  echo $row['tieu_de']; ?> </h2>
        <form  method="post" enctype="multipart/form-data">
            <label >Tiêu Đề </label>
            <input type="text" name="tieude" value="<?php echo $row['tieu_de']; ?>" required>
            
            <label >Id Tin tức</label>
			<select name="tintuc">
				<?php 
 $sql = "SELECT id_tintuc FROM news";
 $result = $conn->query($sql);
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
	  echo "<option value='" . $row["id_tintuc"] . "'>" . $row["id_tintuc"] . "</option>";
	}
  }

				?>
				
			</select>


            <label > Ngày Đăng</label>
            <input type="date" name="ngaydang" value="<?php echo $row['ngay_dang']; ?>">


            
            <button type="submit" name="btn">Sửa đổi</button> <a href="edit_bai_dang.php"><button type="su"
                            class="do">Nhập lại</button></a>
            
        </form>
    </div></table>
</body>
</html>

