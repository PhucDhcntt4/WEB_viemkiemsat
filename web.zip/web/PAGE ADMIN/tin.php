<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="">
    <meta name="author" content="">

    <title>Luật Pháp Việt Nam</title>

    <!-- CSS FILES -->
    <link rel="icon" type="image/x-icon" href="image/news/vienkiemsat.jpg">

<!-- CSS FILES -->
<link href="PAGE USER/css/bootstrap.min.css" rel="stylesheet">

<link href="UPAGE USER/css/bootstrap-icons.css" rel="stylesheet">

<link href="PAGE USER/css/templatemo-kind-heart-charity.css" rel="stylesheet">
    
</head>

<body>

<header class="site-header">
        <div class="container">
            <div class="row">

              

                <div class="col-lg-3 col-12 ms-auto d-lg-block d-none">
                    <ul class="social-icon">
                        <li class="social-icon-item">
                            <a href="#" class="social-icon-link bi-twitter"></a>
                        </li>

                        <li class="social-icon-item">
                            <a href="#" class="social-icon-link bi-facebook"></a>
                        </li>

                        <li class="social-icon-item">
                            <a href="#" class="social-icon-link bi-instagram"></a>
                        </li>

                        <li class="social-icon-item">
                            <a href="#" class="social-icon-link bi-youtube"></a>
                        </li>

                        <li class="social-icon-item">
                            <a href="#" class="social-icon-link bi-whatsapp"></a>
                        </li>
                    </ul>
                </div>

            </div>
        </div>
    </header>

    <nav class="navbar navbar-expand-lg bg-light shadow-lg">
        <div class="container">
            <a class="navbar-brand" href="trangchu.php">
                <img src="image/news/logo.png" class="logo img-fluid" alt="Kind Heart Charity">
                <span>
                    Viện Kiểm Sát Nhân Dân Quận 8
                    <small>Thành Phố Hồ Chí Minh </small>
                </span>
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link click-scroll" href="#top">Trang chủ </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link click-scroll" href="#section_2">Tư tưởng</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link click-scroll" href="#section_3">Thông Tin </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link click-scroll" href="#section_4">Luật</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link click-scroll dropdown-toggle" href="#section_5"
                            id="navbarLightDropdownMenuLink" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">Tin tức</a>

                        <ul class="dropdown-menu dropdown-menu-light" aria-labelledby="navbarLightDropdownMenuLink">
                            <li><a class="dropdown-item" href="news.html">Tin hot </a></li>

                            
                        </ul>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link click-scroll" href="#section_6"></a>
                    </li>

                </ul>
            </div>
        </div>
    </nav>

    <main>


        <section class="news-section section-padding">
            <div class="container">
                <div class="row">

                    <div class="col-lg-7 col-12">
                        <div class="news-block">
                            <div class="news-block-top">
                                <img src="image/news/tin-luat.jpg"
                                    class="news-image img-fluid" alt="">

                                <div class="news-category-block">
                                    <a href="#" class="category-block-link">
                                        
                                    </a>

                                    <a href="#" class="category-block-link">
                                        
                                    </a>
                                </div>
                            </div>

                            <div class="news-block-info">
                                <div class="d-flex mt-2">
                                    <div class="news-block-date">
                                        <p>
                                            <i class="bi-calendar4 custom-icon me-1"></i>
                                            Ngày Hiệu lực 
                                        </p>
                                    </div>

                                    <div class="news-block-author mx-5">
                                        <p>
                                            <i class="bi-person custom-icon me-1"></i>
                                            
                                        </p>
                                    </div>

                                    <div class="news-block-comment">
                                        <p>
                                            <i class="bi-chat-left custom-icon me-1"></i>
                                            48 Comments
                                        </p>
                                    </div>
                                </div>

                                <div class="news-block-title mb-2">
                                    <h4>Pháp luật là gì ?</h4>
                                </div>

                                <div class="news-block-body">
                                    <p><strong>Pháp luật</strong> là một hệ thống các quy tắc xử sự do Nhà nước đặt ra (hoặc thừa nhận) có tính quy phạm phổ biến, tính xác định chặt chẽ về mặt hình thức và tính bắt buộc chung thể hiện ý chí của giai cấp nắm quyền lực Nhà nước và được Nhà nước đảm bảo thực hiện nhằm điều chỉnh các quan hệ xã hội.</p>
                                    <p>Các hình thức thực hiện pháp luật bao gồm:</p>

                                       <p> Sử dụng pháp luật</p>
                                       <p> Tuân thủ pháp luật</p>
                                       <p> Thi hành pháp luật</p>
                                       <p> Áp dụng pháp luật</p>
                                        Bản chất của pháp luật thể hiện ở 2 khía cạnh đó là:

                                        Bản chất giai cấp: Pháp luật do nhà nước ban hành phù hợp với ý chí nguyện vọng của giai cấp cầm quyền mà nhà nước là đại diện.
                                        Bản chất xã hội: Các quy phạm pháp luật bắt nguồn từ thực tiễn đời sống xã hội, do thực tiễn cuộc sống đòi hỏi; Pháp luật không chỉ phản ánh ý chí của giai cấp thống trị mà còn phản ánh nhu cầu, lợi ích của các giai cấp và các tầng lớp dân cư khác nhau trong xã hội; Các quy phạm pháp luật được thực hiện trong thực tiễn đời sống xã hội, vì sự phát triển của xã hội.
                                        Pháp luật có 03 đặc trưng cơ bản đó là:

                                        <p>Tính bắt buộc chung</p>
                                       <p> Tính quy phạm phổ biến</p>
                                       <p> Tính xác định chặt chẽ về mặt hình thức
                                        
                                       </p>
                                

                                    <blockquote>Sed leo nisl, posuere at molestie ac, suscipit auctor mauris. Etiam quis
                                        metus elementum, tempor risus vel, condimentum orci.</blockquote>
                                </div>

                                <div class="row mt-5 mb-4">
                                    <div class="col-lg-6 col-12 mb-4 mb-lg-0">
                                        <img src="PAGE USER/images/news/africa-humanitarian-aid-doctor.jpg"
                                            class="news-detail-image img-fluid" alt="">
                                    </div>

                                    <div class="col-lg-6 col-12">
                                        <img src="PAGE USER/images/news/close-up-happy-people-working-together.jpg"
                                            class="news-detail-image img-fluid" alt="">
                                    </div>
                                </div>

                                <p>You are not allowed to redistribute this template ZIP file on any other template
                                    collection website. Please <a href="https://templatemo.com/contact"
                                        target="_blank">contact TemplateMo</a> for more information.</p>

                                <div class="social-share border-top mt-5 py-4 d-flex flex-wrap align-items-center">
                                    <div class="tags-block me-auto">
                                        <a href="#" class="tags-block-link">
                                            Donation
                                        </a>

                                        <a href="#" class="tags-block-link">
                                            Clothing
                                        </a>

                                        <a href="#" class="tags-block-link">
                                            Food
                                        </a>
                                    </div>

                                    <div class="d-flex">
                                        <a href="#" class="social-icon-link bi-facebook"></a>

                                        <a href="#" class="social-icon-link bi-twitter"></a>

                                        <a href="#" class="social-icon-link bi-printer"></a>

                                        <a href="#" class="social-icon-link bi-envelope"></a>
                                    </div>
                                </div>

                                <div class="author-comment d-flex mt-3 mb-4">
                                    <img src="PAGE USER/images/avatar/studio-portrait-emotional-happy-funny.jpg"
                                        class="img-fluid avatar-image" alt="">

                                    <div class="author-comment-info ms-3">
                                        <h6 class="mb-1">Jack</h6>

                                        <p class="mb-0">Kind Heart Charity is the most supportive organization. This is
                                            Bootstrap 5 HTML CSS template for everyone. Thank you.</p>

                                        <div class="d-flex mt-2">
                                            <a href="#" class="author-comment-link me-3">Like</a>

                                            <a href="#" class="author-comment-link">Reply</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="author-comment d-flex ms-5 ps-3">
                                    <img src="PAGE USER/images/avatar/pretty-blonde-woman-wearing-white-t-shirt.jpg"
                                        class="img-fluid avatar-image" alt="">

                                    <div class="author-comment-info ms-3">
                                        <h6 class="mb-1">Daisy</h6>

                                        <p class="mb-0">Sed leo nisl, posuere at molestie ac, suscipit auctor mauris.
                                            Etiam quis metus elementum, tempor risus vel, condimentum orci</p>

                                        <div class="d-flex mt-2">
                                            <a href="#" class="author-comment-link me-3">Like</a>

                                            <a href="#" class="author-comment-link">Reply</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="author-comment d-flex mt-3 mb-4">
                                    <img src="PAGE USER/images/avatar/portrait-young-redhead-bearded-male.jpg"
                                        class="img-fluid avatar-image" alt="">

                                    <div class="author-comment-info ms-3">
                                        <h6 class="mb-1">Wilson</h6>

                                        <p class="mb-0">Lorem Ipsum dolor sit amet, consectetur adipsicing kengan omeg
                                            kohm tokito Professional charity theme based on Bootstrap</p>

                                        <div class="d-flex mt-2">
                                            <a href="#" class="author-comment-link me-3">Like</a>

                                            <a href="#" class="author-comment-link">Reply</a>
                                        </div>
                                    </div>
                                </div>

                                <form class="custom-form comment-form mt-4" action="#" method="post" role="form">
                                    <h6 class="mb-3">Write a comment</h6>

                                    <textarea name="comment-message" rows="4" class="form-control" id="comment-message"
                                        placeholder="Your comment here"></textarea>

                                    <div class="col-lg-3 col-md-4 col-6 ms-auto">
                                        <button type="submit" class="form-control">Comment</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-12 mx-auto mt-4 mt-lg-0">
                        <form class="custom-form search-form" action="#" method="post" role="form">
                            <input class="form-control" type="search" placeholder="Search" aria-label="Search">

                            <button type="submit" class="form-control">
                            <i class='bx bx-search'></i>
                            </button>
                        </form>

                        <h5 class="mt-5 mb-3">Recent news</h5>

                        <div class="news-block news-block-two-col d-flex mt-4">
                            <div class="news-block-two-col-image-wrap">
                                <a href="news-detail.html">
                                    <img src="PAGE USER/images/news/africa-humanitarian-aid-doctor.jpg"
                                        class="news-image img-fluid" alt="">
                                </a>
                            </div>

                            <div class="news-block-two-col-info">
                                <div class="news-block-title mb-2">
                                    <h6><a href="news-detail.html" class="news-block-title-link">Food donation area</a>
                                    </h6>
                                </div>

                                <div class="news-block-date">
                                    <p>
                                        <i class="bi-calendar4 custom-icon me-1"></i>
                                        October 16, 2036
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="news-block news-block-two-col d-flex mt-4">
                            <div class="news-block-two-col-image-wrap">
                                <a href="news-detail.html">
                                    <img src="PAGE USER/images/news/close-up-happy-people-working-together.jpg"
                                        class="news-image img-fluid" alt="">
                                </a>
                            </div>

                            <div class="news-block-two-col-info">
                                <div class="news-block-title mb-2">
                                    <h6><a href="news-detail.html" class="news-block-title-link">Volunteering Clean</a>
                                    </h6>
                                </div>

                                <div class="news-block-date">
                                    <p>
                                        <i class="bi-calendar4 custom-icon me-1"></i>
                                        October 20, 2036
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="category-block d-flex flex-column">
                            <h5 class="mb-3">Categories</h5>

                            <a href="#" class="category-block-link">
                                Drinking water
                                <span class="badge">20</span>
                            </a>

                            <a href="#" class="category-block-link">
                                Food Donation
                                <span class="badge">30</span>
                            </a>

                            <a href="#" class="category-block-link">
                                Children Education
                                <span class="badge">10</span>
                            </a>

                            <a href="#" class="category-block-link">
                                Poverty Development
                                <span class="badge">15</span>
                            </a>

                            <a href="#" class="category-block-link">
                                Clothing Donation
                                <span class="badge">20</span>
                            </a>
                        </div>

                        <div class="tags-block">
                            <h5 class="mb-3">Tags</h5>

                            <a href="#" class="tags-block-link">
                                Donation
                            </a>

                            <a href="#" class="tags-block-link">
                                Clothing
                            </a>

                            <a href="#" class="tags-block-link">
                                Food
                            </a>

                            <a href="#" class="tags-block-link">
                                Children
                            </a>

                            <a href="#" class="tags-block-link">
                                Education
                            </a>

                            <a href="#" class="tags-block-link">
                                Poverty
                            </a>

                            <a href="#" class="tags-block-link">
                                Clean Water
                            </a>
                        </div>

                        <form class="custom-form subscribe-form" action="#" method="post" role="form">
                            <h5 class="mb-4">Newsletter Form</h5>

                            <input type="email" name="subscribe-email" id="subscribe-email" pattern="[^ @]*@[^ @]*"
                                class="form-control" placeholder="Email Address" required>

                            <div class="col-lg-12 col-12">
                                <button type="submit" class="form-control">Subscribe</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </section>

        <section class="news-section section-padding section-bg">
            <div class="container">
                <div class="row">

                    <div class="col-lg-12 col-12 mb-4">
                        <h2>Related news</h2>
                    </div>

                    <div class="col-lg-6 col-12">
                        <div class="news-block">
                            <div class="news-block-top">
                                <a href="news-detail.html">
                                    <img src="PAGE USER/images/news/medium-shot-volunteers-with-clothing-donations.jpg"
                                        class="news-image img-fluid" alt="">
                                </a>

                                <div class="news-category-block">
                                    <a href="#" class="category-block-link">
                                        Lifestyle,
                                    </a>

                                    <a href="#" class="category-block-link">
                                        Clothing Donation
                                    </a>
                                </div>
                            </div>

                            <div class="news-block-info">
                                <div class="d-flex mt-2">
                                    <div class="news-block-date">
                                        <p>
                                            <i class="bi-calendar4 custom-icon me-1"></i>
                                            October 16, 2036
                                        </p>
                                    </div>

                                    <div class="news-block-author mx-5">
                                        <p>
                                            <i class="bi-person custom-icon me-1"></i>
                                            By Admin
                                        </p>
                                    </div>

                                    <div class="news-block-comment">
                                        <p>
                                            <i class="bi-chat-left custom-icon me-1"></i>
                                            24 Comments
                                        </p>
                                    </div>
                                </div>

                                <div class="news-block-title mb-2">
                                    <h4><a href="news-detail.html" class="news-block-title-link">Clothing donation to
                                            urban area</a></h4>
                                </div>

                                <div class="news-block-body">
                                    <p>Lorem Ipsum dolor sit amet, consectetur adipsicing kengan omeg kohm tokito
                                        Professional charity theme based on Bootstrap</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 col-12">
                        <div class="news-block">
                            <div class="news-block-top">
                                <a href="news-detail.html">
                                    <img src="PAGE USER/images/news/medium-shot-people-collecting-foodstuff.jpg"
                                        class="news-image img-fluid" alt="">
                                </a>

                                <div class="news-category-block">
                                    <a href="#" class="category-block-link">
                                        Food,
                                    </a>

                                    <a href="#" class="category-block-link">
                                        Donation,
                                    </a>

                                    <a href="#" class="category-block-link">
                                        Caring
                                    </a>
                                </div>
                            </div>

                            <div class="news-block-info">
                                <div class="d-flex mt-2">
                                    <div class="news-block-date">
                                        <p>
                                            <i class="bi-calendar4 custom-icon me-1"></i>
                                            October 20, 2036
                                        </p>
                                    </div>

                                    <div class="news-block-author mx-5">
                                        <p>
                                            <i class="bi-person custom-icon me-1"></i>
                                            By Admin
                                        </p>
                                    </div>

                                    <div class="news-block-comment">
                                        <p>
                                            <i class="bi-chat-left custom-icon me-1"></i>
                                            36 Comments
                                        </p>
                                    </div>
                                </div>

                                <div class="news-block-title mb-2">
                                    <h4><a href="news-detail.html" class="news-block-title-link">Food donation area</a>
                                    </h4>
                                </div>

                                <div class="news-block-body">
                                    <p>Sed leo nisl, posuere at molestie ac, suscipit auctor mauris. Etiam quis metus
                                        elementum, tempor risus vel, condimentum orci</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
    </main>

    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-12 mb-4">
                    <img src="images/logo.png" class="logo img-fluid" alt="">
                </div>

                <div class="col-lg-4 col-md-6 col-12 mb-4">
                    <h5 class="site-footer-title mb-3">Quick Links</h5>

                    <ul class="footer-menu">
                        <li class="footer-menu-item"><a href="#" class="footer-menu-link">Our Story</a></li>

                        <li class="footer-menu-item"><a href="#" class="footer-menu-link">Newsroom</a></li>

                        <li class="footer-menu-item"><a href="#" class="footer-menu-link">Causes</a></li>

                        <li class="footer-menu-item"><a href="#" class="footer-menu-link">Become a volunteer</a></li>

                        <li class="footer-menu-item"><a href="#" class="footer-menu-link">Partner with us</a></li>
                    </ul>
                </div>

                <div class="col-lg-4 col-md-6 col-12 mx-auto">
                    <h5 class="site-footer-title mb-3">Contact Infomation</h5>

                    <p class="text-white d-flex mb-2">
                        <i class="bi-telephone me-2"></i>

                        <a href="tel: 305-240-9671" class="site-footer-link">
                            305-240-9671
                        </a>
                    </p>

                    <p class="text-white d-flex">
                        <i class="bi-envelope me-2"></i>

                        <a href="mailto:info@yourgmail.com" class="site-footer-link">
                            donate@charity.org
                        </a>
                    </p>

                    <p class="text-white d-flex mt-3">
                        <i class="bi-geo-alt me-2"></i>
                        Akershusstranda 20, 0150 Oslo, Norway
                    </p>

                    <a href="#" class="custom-btn btn mt-3">Get Direction</a>
                </div>
            </div>
        </div>

        <div class="site-footer-bottom">
            <div class="container">
                <div class="row">

                    <div class="col-lg-6 col-md-7 col-12">
                        <p class="copyright-text mb-0">Copyright © 2036 <a href="#">Kind Heart</a> Charity Org.
                            Design: <a href="https://templatemo.com" target="_blank">TemplateMo</a> <br>Distribution: <a
                                href="https://themewagon.com">ThemeWagon</a></p>
                    </div>

                    <div class="col-lg-6 col-md-5 col-12 d-flex justify-content-center align-items-center mx-auto">
                        <ul class="social-icon">
                            <li class="social-icon-item">
                                <a href="#" class="social-icon-link bi-twitter"></a>
                            </li>

                            <li class="social-icon-item">
                                <a href="#" class="social-icon-link bi-facebook"></a>
                            </li>

                            <li class="social-icon-item">
                                <a href="#" class="social-icon-link bi-instagram"></a>
                            </li>

                            <li class="social-icon-item">
                                <a href="#" class="social-icon-link bi-linkedin"></a>
                            </li>

                            <li class="social-icon-item">
                                <a href="https://youtube.com/templatemo" class="social-icon-link bi-youtube"></a>
                            </li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </footer>

    <!-- JAVASCRIPT FILES -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/click-scroll.js"></script>
    <script src="js/counter.js"></script>
    <script src="js/custom.js"></script>

</body>

</html>