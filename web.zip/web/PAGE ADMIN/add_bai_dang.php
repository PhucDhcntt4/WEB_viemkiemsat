<?php
     include('config/connect.php');

    if(isset ($_POST['btn'])){
       $tieude = $_POST['tieude'];
       $tintuc = $_POST['tintuc'];
       $ngaydang = $_POST['ngaydang'];
       
       $sql = "INSERT INTO bai_dang (tieu_de, id_tintuc, ngay_dang)
       VALUES ('$tieude', '$tintuc','$ngaydang') ";
        mysqli_query($conn, $sql);

      

        header("location:bai_dang.php");
    }
    
       
?>
