<?php

// Kết nối với cơ sở dữ liệu
include "connect.php";

// Lấy ID và trạng thái slide từ URL
$id = $_GET['id'];
$status = $_GET['status'];

// Cập nhật trạng thái slide
$sql = "UPDATE slides SET status = $status WHERE id = $id";
mysqli_query($conn, $sql);

// Chuyển hướng đến trang quản lý slide
header("location: Slide.php");

?>
