<?php
    include"config/connect.php"; 
    
    $this_id = $_GET['this_id'];

    echo $this_id;

    $sql = "DELETE FROM luat WHERE id_luat ='$this_id' ";

    mysqli_query($conn, $sql);

    header("location: law.php");
?>

