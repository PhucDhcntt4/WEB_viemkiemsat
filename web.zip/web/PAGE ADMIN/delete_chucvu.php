<?php
    include"config/connect.php"; 
    
    $this_id = $_GET['this_id'];

    echo $this_id;

    $sql = "DELETE FROM chuc_vu WHERE Ma_cong_chuc ='$this_id' ";

    mysqli_query($conn, $sql);

    header("location: indexadmin.php");
?>

