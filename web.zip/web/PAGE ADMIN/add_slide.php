<?php
     include('config/connect.php');

    if(isset ($_POST['btn'])){
       $title = $_POST['title'];
       $image = $_FILES['image']['name'];
       $image_tmp_name = $_FILES['image']['tmp_name'];
       $status = $_POST['status'];
       
       $sql = "INSERT INTO slides (title, image, status)
       VALUES ('$title', '$$image','$status') ";
        mysqli_query($conn, $sql);

        move_uploaded_file($image_tmp_name, 'PAGE USER/images/slide/'.$image );

        header("location:Slide.php");
    }
    
       
?>
