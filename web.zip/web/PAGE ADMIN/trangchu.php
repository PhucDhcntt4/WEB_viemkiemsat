<?php 
    $fp = 'image/news/dem.txt';

    $fo = fopen($fp, 'r');
    $count = fread($fo, filesize($fp));
    $count ++;
    $fc = fclose($fo);
    $fo = fopen($fp, 'w');
    $fw = fwrite($fo, $count);
    $fc = fclose($fo);
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="icon" type="image/x-icon" href="image/news/vienkiemsat.jpg">

    <!-- CSS FILES -->
    <link href="PAGE USER/css/bootstrap.min.css" rel="stylesheet">

    <link href="UPAGE USER/css/bootstrap-icons.css" rel="stylesheet">

    <link href="PAGE USER/css/templatemo-kind-heart-charity.css" rel="stylesheet">
    <!--
-->
    <title>Viện Kiểm sát nhân dân Quận 8</title>
</head>

<body id="section_1">

    <header class="site-header">
        <div class="container">
            <div class="row">



                <div class="col-lg-3 col-12 ms-auto d-lg-block d-none">
                    <ul class="social-icon">
                        <li class="social-icon-item">
                            <a href="#" class="social-icon-link bi-twitter"></a>
                        </li>

                        <li class="social-icon-item">
                            <a href="#" class="social-icon-link bi-facebook"></a>
                        </li>

                        <li class="social-icon-item">
                            <a href="#" class="social-icon-link bi-instagram"></a>
                        </li>

                        <li class="social-icon-item">
                            <a href="#" class="social-icon-link bi-youtube"></a>
                        </li>

                        <li class="social-icon-item">
                            <a href="#" class="social-icon-link bi-whatsapp"></a>
                        </li>
                    </ul>
                </div>

            </div>
        </div>
    </header>

    <nav class="navbar navbar-expand-lg bg-light shadow-lg">
        <div class="container">
            <a class="navbar-brand" href="trangchu.php">
                <img src="image/news/logo.png" class="logo img-fluid" alt="Kind Heart Charity">
                <span>
                    Viện Kiểm Sát Nhân Dân Quận 8
                    <small>Thành Phố Hồ Chí Minh </small>
                </span>
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link click-scroll" href="#top">Trang chủ </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link click-scroll" href="#section_2">Tư tưởng</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link click-scroll" href="#section_3">Thông Tin </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link click-scroll" href="#section_4">Luật</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link click-scroll dropdown-toggle" href="#section_5"
                            id="navbarLightDropdownMenuLink" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">Tin tức</a>

                        <ul class="dropdown-menu dropdown-menu-light" aria-labelledby="navbarLightDropdownMenuLink">
                            <li><a class="dropdown-item" href="news.html">Tin hot </a></li>


                        </ul>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link click-scroll" href="#section_6"></a>
                    </li>

                </ul>
            </div>
        </div>
    </nav>

    <main>
        <section class="hero-section hero-section-full-height">
            <div class="container-fluid">
                <div class="row">

                    <div class="col-lg-12 col-12 p-0">
                        <div id="hero-slide" class="carousel carousel-fade slide" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <?php
                                    include "config/connect.php";
                                    $sql_slider = mysqli_query($conn,"SELECT * FROM slides WHERE status='1'AND id = '1'");
                                    if ($row_slider = mysqli_fetch_array($sql_slider)){?>
                                    <img src="PAGE USER/images/slide/<?php echo $row_slider['image']?>"
                                        class="carousel-image img-fluid" alt="...">


                                    <?php  }
                                ?>
                                </div>

                                <div class="carousel-item active">
                                    <?php
                                    include "config/connect.php";
                                    $sql_slider = mysqli_query($conn,"SELECT * FROM slides WHERE status='1'AND id = '2'");
                                    if ($row_slider = mysqli_fetch_array($sql_slider)){?>
                                    <img src="PAGE USER/images/slide/<?php echo $row_slider['image']?>"
                                        class="carousel-image img-fluid" alt="...">


                                    <?php  }
                                ?>
                                </div>

                                <div class="carousel-item active">
                                    <?php
                                    include "config/connect.php";
                                    $sql_slider = mysqli_query($conn,"SELECT * FROM slides WHERE status='1'AND id = '4'");
                                    if ($row_slider = mysqli_fetch_array($sql_slider)){?>
                                    <img src="PAGE USER/images/slide/<?php echo $row_slider['image']?>"
                                        class="carousel-image img-fluid" alt="...">


                                    <?php  }
                                ?>
                                </div>

                                <div class="carousel-item active">
                                    <?php
                                    include "config/connect.php";
                                    $sql_slider = mysqli_query($conn,"SELECT * FROM slides WHERE status='1'AND id = '5'");
                                    if ($row_slider = mysqli_fetch_array($sql_slider)){?>
                                    <img src="PAGE USER/images/slide/<?php echo $row_slider['image']?>"
                                        class="carousel-image img-fluid" alt="...">


                                    <?php  }
                                ?>
                                </div>



                                <button class="carousel-control-prev" type="button" data-bs-target="#hero-slide"
                                    data-bs-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Previous</span>
                                </button>

                                <button class="carousel-control-next" type="button" data-bs-target="#hero-slide"
                                    data-bs-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Next</span>
                                </button>
                            </div>
                        </div>

                    </div>
                </div>
        </section>
        <section class="section-padding" id="section_4">
            <div class="container">
                <div class="row">

                    <div class="col-lg-10 col-12 text-center mx-auto">
                        <h2 class="mb-5">Thông tin Luật</h2>
                    </div>

                    <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0">
                        <div class="featured-block d-flex justify-content-center align-items-center">
                            <a href="donate.html" class="d-block">
                                <img src="image/news/hinh-su.jpg" class="featured-block-image img-fluid" alt="">

                                <p class="featured-block-text"><strong>Luật Hình Sự</strong></p>
                            </a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0 mb-md-4">
                        <div class="featured-block d-flex justify-content-center align-items-center">
                            <a href="donate.html" class="d-block">
                                <img src="image/news/dansu.png" class="featured-block-image img-fluid" alt="">

                                <p class="featured-block-text"><strong>Luật Dân Sự</strong> </p>
                            </a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0 mb-md-4">
                        <div class="featured-block d-flex justify-content-center align-items-center">
                            <a href="donate.html" class="d-block">
                                <img src="image/news/laodong.jpg" class="featured-block-image img-fluid" alt="">

                                <p class="featured-block-text"><strong>Luật Lao Động</strong></p>
                            </a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0">
                        <div class="featured-block d-flex justify-content-center align-items-center">
                            <a href="donate.html" class="d-block">
                                <img src="image/news/thue.png" class="featured-block-image img-fluid" alt="">

                                <p class="featured-block-text"><strong>Luật Thuế</strong> </p>
                            </a>
                        </div>
                    </div>

                    <div class="col-lg-10 col-12 text-center mx-auto">
                        <h2 class="mb-5"><button type="button" class="btn btn-secondary">Xem Thêm</button></h2>
                    </div>

                </div>
            </div>
        </section>

        <section class="section-padding section-bg" id="section_2">
            <div class="container">
                <div class="row">

                    <div class="col-lg-6 col-12 mb-5 mb-lg-0">
                        <img src="image/news/hcm.jpg" class="custom-text-box-image img-fluid" alt="">
                    </div>

                    <div class="col-lg-6 col-12">
                        <div class="custom-text-box">
                            <h2 class="mb-2">Học tập và làm theo tấm gương đạo đức Hồ Chí Minh</h2>

                            <h5 class="mb-3">“Nêu cao tinh thần trách nhiệm” của cán bộ, đảng viên, công chức theo tư
                                tưởng Hồ Chí Minh</h5>

                            <p class="mb-0">Hai chữ “trách nhiệm” không chỉ bó hẹp để nói về những người có chức trách,
                                những người lãnh đạo, mà theo nghĩa rộng, là để chỉ về bất cứ ai, làm bất cứ công việc
                                gì; Tinh thần trách nhiệm của mỗi người, mỗi cán bộ, đảng viên luôn gắn liền với phẩm
                                chất đạo đức, với truyền thống dân tộc. Quần chúng nhân dân có trách nhiệm đối với gia
                                đình, xã hội, Tổ quốc. Cán bộ, đảng viên là những người tiên phong thì phải có tinh thần
                                trách nhiệm cao hơn để làm gương cho quần chúng nhân dân noi theo và phải hết lòng, hết
                                sức phụng sự Tổ quốc, phục vụ nhân dân.</p>
                        </div>


                    </div>


                    <div class="col-lg-10 col-12 text-center mx-auto">
                        <h2 class="mb-5"><button type="button" class="btn btn-secondary">Xem Thêm</button></h2>
                    </div>
                </div>
            </div>
        </section>


        <section class="about-section section-padding">
            <div class="container">
                <div class="row">

                    <div class="col-lg-6 col-md-5 col-12">
                        <img src="image/news/thanhnien.jpg" class="about-image ms-lg-auto bg-light shadow-lg img-fluid"
                            alt="">
                    </div>

                    <div class="col-lg-5 col-md-7 col-12">
                        <div class="custom-text-block">
                            <h2 class="mb-0">Đoàn thanh niên</h2>

                            <p class="text-muted mb-lg-4 mb-md-4">Đoàn thanh niên Viện KSND TPHCM hỗ trợ trao 200 phần
                                quà tết dành cho hộ dân khó khăn trên địa bà xã An Thới Đông, huyện Cần Giờ</p>

                            <p>Nhân dịp mừng xuân Quý Mão năm 2023, với mục đích san sẻ yêu thương, chăm lo đời sống cho
                                những hoàn cảnh khó khăn, ngày 14/01/2023, Đoàn Cơ sở Viện kiểm sát nhân dân Thành phố
                                Hồ Chí Minh và Đoàn TNCS Sở Công thương đã phối hợp với Ủy ban nhân dân, Ủy ban Mặt trận
                                Tổ quốc xã An Thới Đông, huyện Cần Giờ thực hiện chương trình “Tết gắn kết yêu thương”.
                            </p>

                            <p>Tham dự chương trình có đ/c Huỳnh Tấn Lợi – Bí thư Đoàn cơ sở Viện kiểm sát nhân dân
                                TP.Hồ Chí Minh, cùng các đồng chí đại diện Đoàn TNCS Sở Công thương TP.Hồ Chí Minh
                                Theo đó, chương trình đã hỗ trợ trao 200 phần quà Tết dành cho các hộ dân khó khăn trên
                                địa bàn xã An Thới Đông, huyện Cần Giờ. Những suất quà ấm áp, nghĩa tình của các đơn vị
                                đã đem đến niềm vui nhỏ trước thềm tết Nguyên đán 2023 cho các hộ gia đình.
                                Đây là hoạt động có ý nghĩa thiết thực, thể hiện tấm lòng tương thân, tương ái của các
                                đoàn viên, thanh niên Viện kiểm sát nhân dân Thành phố Hồ Chí Minh nhằm chia sẻ, động
                                viên những gia đình có hoàn cảnh đặc biệt khó khăn đón Tết đầm ấm, sum vầy.


                            </p>
                        </div>
                    </div>
                    <div class="col-lg-10 col-12 text-center mx-auto">
                        <h2 class="mb-5"><button type="button" class="btn btn-secondary">Xem Thêm</button></h2>
                    </div>
                </div>
            </div>
        </section>




        <section class="section-padding" id="section_3">
            <div class="container">
                <div class="row">

                    <div class="col-lg-12 col-12 text-center mb-4">
                        <h2>Our Causes</h2>
                    </div>

                    <div class="col-lg-4 col-md-6 col-12 mb-4 mb-lg-0">
                        <div class="custom-block-wrap">
                            <img src="image/news/thông-tin.jpg" class="custom-block-image img-fluid" alt="">

                            <div class="custom-block">
                                <div class="custom-block-body">
                                    <h5 class="mb-3">Phần mềm Tra cứu thông tin điều luật</h5>

                                    <p> Phòng Thống kê tội phạm và Công nghệ thông tin gửi bản dùng thử phần mềm Tra cứu
                                        thông tin điều luật.</p>

                                </div>

                                <a href="donate.html" class="custom-btn btn">CHI TIẾT </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-12 mb-4 mb-lg-0">
                        <div class="custom-block-wrap">
                            <img src="image/news/cns.jpg" class="custom-block-image img-fluid" alt="">

                            <div class="custom-block">
                                <div class="custom-block-body">
                                    <h5 class="mb-3">An toàn thông tin cá nhân </h5>

                                    <p>Tôi có thắc mắc muốn được giải đáp như sau số điện thoại của cá nhân được xếp vào
                                        nhóm dữ liệu cá nhân nhạy cảm hay dữ liệu cá nhân cơ bản theo quy định?</p>
                                    <p>

                                    </p>

                                </div>

                                <a href="donate.html" class="custom-btn btn">CHI TIẾT</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="custom-block-wrap">
                            <img src="image/news/canhan.jpg" class="custom-block-image img-fluid" alt="">

                            <div class="custom-block">
                                <div class="custom-block-body">
                                    <h5 class="mb-3">Dữ liệu cá nhân có được mua bán hay không?</h5>

                                    <p>Dữ liệu cá nhân có được mua bán hay không? Hành vi nào là hành vi bị nghiêm cấm
                                        trong bảo vệ dữ liệu cá nhân?
                                    </p>

                                </div>

                                <a href="donate.html" class="custom-btn btn">CHI TIẾT</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-10 col-12 text-center mx-auto">
                        <h2 class="mb-5"><button type="button" class="btn btn-secondary">Xem Thêm</button></h2>
                    </div>
                </div>
            </div>
        </section>






        \

        <section class="contact-section section-padding" id="section_6">
            <div class="container">
                <div class="row">

                    <div class="col-lg-4 col-12 ms-auto mb-5 mb-lg-0">
                        <div class="contact-info-wrap">
                            <h2>LIÊN LẠC</h2>

                            <div class="contact-image-wrap d-flex flex-wrap">
                                <img src="image/news/logo.png" class="img-fluid avatar-image" alt="">

                                <div class="d-flex flex-column justify-content-center ms-3">
                                    <p class="mb-0">VIỆN KIỂM SÁT NHÂN DÂN QUÂN 8 </p>
                                    <p class="mb-0"><strong>THÀNH PHỐ HỒ CHÍ MINH</strong></p>
                                </div>
                            </div>

                            <div class="contact-info">
                                <h5 class="mb-3">THÔNG TIN </h5>

                                <p class="d-flex mb-2">
                                    <i class="bi-geo-alt me-2"></i>
                                    11 Dương Quang Đông, Phường 5, Quận 8, Thành phố Hồ Chí Minh
                                </p>

                                <p class="d-flex mb-2">
                                    <i class="bi-telephone me-2"></i>

                                    <a href="tel:  028 3851 5859">
                                        028 3851 5859
                                    </a>
                                </p>

                                <p class="d-flex">
                                    <i class="bi-envelope me-2"></i>

                                    <a href="mailto:viemkiemsatnhandanquan8@gmail.com">
                                        vienkiemsatnhandanquan8@gmail.com
                                    </a>
                                </p>


                            </div>
                        </div>
                    </div>

                    <div class="col-lg-5 col-12 mx-auto">
                        <form class="custom-form contact-form" action="#" method="post" role="form">
                            <h2>Mẫu liên hệ </h2>

                            <p class="mb-4">Hoặc có thể gửi thông tin qua mail :
                                <a href="#">vienkiemsatnhandanquan8@gmail.com</a>
                            </p>


                            <input type="email" name="email" id="email" pattern="[^ @]*@[^ @]*" class="form-control"
                                placeholder=".....@gmail.com" required>

                            <textarea name="message" rows="5" class="form-control" id="message"
                                placeholder="Bạn cần giúp đỡ gì?"></textarea>

                            <button type="submit" class="form-control">Gửi thông tin </button>
                        </form>
                    </div>

                </div>
            </div>
        </section>
    </main>

    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-12 mb-4">
                    <img src="images/logo.png" class="logo img-fluid" alt="">
                </div>


                <div class="col-lg-4 col-md-6 col-12 mx-auto">
                    <h5 class="site-footer-title mb-3">TRANG THÔNG TIN ĐIỆN TỬ CỦA VIỆN KIỂM SÁT NHÂN DÂN THÀNH PHỐ HỒ
                        CHÍ MINH</h5>

                    <p class="text-white d-flex mb-2">
                        <i class="bi-telephone me-2"></i>

                        <a href="tel: 305-240-9671" class="site-footer-link">
                            Điện thoại :(08) 3.8291741
                        </a>
                    </p>

                    <p class="text-white d-flex">
                        <i class="bi-envelope me-2"></i>

                        <a href="mailto:info@yourgmail.com" class="site-footer-link">
                            © Viện kiểm sát nhân dân TP.HCM giữ bản quyền.
                        </a>
                    </p>

                    <p class="text-white d-flex mt-3">
                        <i class="bi-geo-alt me-2"></i>
                        Trụ sở:120 Nam Kỳ Khởi Nghĩa, Phường Bến Nghé, Quận 1, TPHCM
                    </p>

                    <a href="#" class="custom-btn btn mt-3">Về Lại Trang Đầu</a>
                </div>
            </div>
        </div>

        <div class="site-footer-bottom">
            <div class="container">
                <div class="row">

                    <div class="col-lg-6 col-md-7 col-12">
                        <p class="copyright-text mb-0">Copyright Nhom 14 <a href="#">TUP</a>
                            Design: <a href="https://templatemo.com" target="_blank">TUP</a><br>
                        </p>
                    </div>

                </div>
            </div>
        </div>
    </footer>

    <script src="PAGE USER/js/jquery.min.js"></script>
    <script src="PAGE USER/js/bootstrap.min.js"></script>
    <script src="PAGE USER/js/jquery.sticky.js"></script>
    <script src="PAGE USER/js/click-scroll.js"></script>
    <script src="PAGE USER/js/counter.js"></script>
    <script src="PAGE USER/js/custom.js"></script>

</body>

</html>