<?php
     include('config/connect.php');

    if(isset ($_POST['btn'])){
       $type = $_POST['type'];
       $name = $_POST['name'];
       $ngaydang = $_POST['ngaydang'];
       
       $sql = "INSERT INTO vanban (type, name, day_post)
       VALUES ('$type', '$name','$ngaydang') ";
        mysqli_query($conn, $sql);


        header("location:van_ban.php");
    }
    
       
?>
