<?php 
    $fp = 'image/news/dem.txt';

    $fo = fopen($fp, 'r');
    $count = fread($fo, filesize($fp));
    $count ++;
    $fc = fclose($fo);
    $fo = fopen($fp, 'w');
    $fw = fwrite($fo, $count);
    $fc = fclose($fo);
?>


<h2>Thống kê truy cập </h2>
<p>Hiện có <span><?php echo $count; ?> <span></span> </p>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="css/bang.css">
</head>
<body>

<div class="container">
  <h2>Modal Example</h2>
  <!-- Button to Open the Modal -->
  <span type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
    Open modal
  </span>

  <!-- The Modal -->
  <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Modal Heading</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
        <div class="container">
        <h2>Add Product</h2>
        <form action="add_new.php" method="post" enctype="multipart/form-data">
            <label >Tiêu Đề </label>
            <input type="text" name="tieude" required>
            
            <label >Nội Dung </label>
            <input type="text" name="noidung" rows="4" required></input>

            <label > Image </label>
            <input type="file" name="image" required>

            <label > Ngày Đăng</label>
            <input type="date" name="ngaydang">

            <button type="submit" name="btn">Thêm</button> <a href="add_new.php"><button type="submit" class="do">Nhập lại</button></a>
            
        </form>
    </div>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
  
</div>

</body>
</html>

