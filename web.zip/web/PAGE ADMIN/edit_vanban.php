<?php 
    include"config/connect.php";    

    $this_id = $_GET['this_id'];


    $sql = "SELECT * FROM vanban WHERE id_van_ban = ".$this_id ;

    $query = mysqli_query($conn, $sql);

    $row = mysqli_fetch_assoc($query);

    if(isset($_POST['btn']) ){

        $type = $_POST['type'];
        $name = $_POST['name'];
        $ngaydang = $_POST['ngaydang'];

        $sql = "UPDATE vanban SET type ='$type',
         name ='$name', day_post = '$ngaydang' WHERE id_van_ban =".$this_id;

        mysqli_query($conn, $sql);

    
        header("location: van_ban.php");
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="css/edit.css">

   
</head>
<body>
    <table>
    <div class="container">
        <form  method="post" enctype="multipart/form-data">
            <label >Type </label>
            <select name="type">
                <option value="<?php echo $row['type']?>"></option>
                <option value="Kiểm sát nhân dân">Kiểm sát nhân dân </option>
                <option value="Văn bản quy phạm pháp luật">Văn bản quy phạm pháp luật</option>
            </select> 
            
            <label >Tên Văn bản </label>
            <input type="text" name="name" value="<?php echo $row['name']; ?>" required>

            <label > Ngày đăng </label>
            <input type="date" name="ngaydang" value="<?php echo $row['day_post']?>" required>

           


            
            <button type="submit" name="btn">Sửa đổi</button> <a href="edit_vanban.php"><button type="su"
                            class="do">Nhập lại</button></a>
            
        </form>
    </div></table>
</body>
</html>

 