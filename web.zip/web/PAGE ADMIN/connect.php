<?php 

    $server = 'localhost';
    $user = 'root';
    $pass = "";
    $database ='test';


    $conn = new mysqli($server, $user, $pass, $database );

    if($conn){
        mysqli_query($conn, " SET NAMES 'utf8' ");
       // echo 'Đã kết nối thành công DATABASE';

    }
    else{

        echo " Kết nối DATABASE thất bại!";
    }
     
    mysqli_set_charset($conn, 'utf8');

?>