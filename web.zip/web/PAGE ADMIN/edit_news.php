<?php 
    include"connect.php";    

    $this_id = $_GET['this_id'];


    $sql = "SELECT * FROM news WHERE id_tintuc = ".$this_id ;

    $query = mysqli_query($conn, $sql);

    $row = mysqli_fetch_assoc($query);

    if(isset($_POST['btn']) ){

        $tieude = $_POST['tieude'];
        $noidung = $_POST['noidung'];
        $image = $_FILES['image']['name'];
        $image_tmp_name = $_FILES['image']['tmp_name'];
        $ngaydang = $_POST['ngaydang'];

        $sql = "UPDATE news SET tieu_de='$tieude', noi_dung = '$noidung',
         image ='$image', ngay_dang = '$ngaydang' WHERE id_tintuc=".$this_id;

        mysqli_query($conn, $sql);

        move_uploaded_file($image_tmp_name, 'image/news/'.$image );
       
        header("location: adminnew.php");
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="css/bang.css">
    <title>Add Product</title>
   
</head>
<body>
    <div class="container">
    <h2><?php  echo $row['tieu_de']; ?> </h2>
        <form  method="post" enctype="multipart/form-data">
            <label >Tiêu Đề </label>
            <input type="text" name="tieude" value="<?php echo $row['tieu_de']; ?>" required>
            
            <label >Nội Dung </label>
            <input type="text"  name="noidung" rows="4" value="<?php echo $row['noi_dung']; ?>"required></input>

            <label > Image </label>
            <span><img src="image/news/<?php echo $row['image']; ?>" alt="" width="30" height="40"></span>
            <input type="file" name="image"  required>

            <label > Ngày Đăng</label>
            <input type="date" name="ngaydang" value="<?php echo $row['ngay_dang']; ?>">


            
            <button type="submit" name="btn">Edit</button> <a href="edit_news.php"><button type="submit" class="do">Hủy</button></a>
            
        </form>
    </div>
</body>
</html>


<h1>Tin tức</h1> 
<h4><?php  echo $row['tieu_de']; ?> </h4>

<form method="post" enctype="multipart/form-data">

    <p>Tiêu đề </p>
    <input type="text" name="tieude" value="<?php echo $row['tieu_de']; ?>">

    <p>Nội dung </p>
    <input type="text" name="noidung" value="<?php echo $row['noi_dung']; ?>">

    <p>Image</p>
    <span><img src="image/news/<?php echo $row['image']; ?>" alt="" width="30" height="40"></span>
    <input type="file" name="image">

    <p>Ngày đăng</p>
    <input type="date" name="ngaydang" value="<?php echo $row['ngay_dang']; ?>">
    <br>
    <button name="btn">Edit</button>

</form>

