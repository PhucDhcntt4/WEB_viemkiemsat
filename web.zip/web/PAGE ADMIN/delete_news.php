<?php
    include"connect.php"; 
    
    $this_id = $_GET['this_id'];

    echo $this_id;

    $sql = "DELETE FROM news WHERE id_tintuc='$this_id' ";

    mysqli_query($conn, $sql);

    header("location: adminnew.php");
?>

