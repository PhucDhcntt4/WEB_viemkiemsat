<?php
     include('config/connect.php');

    if(isset ($_POST['btn'])){
       $type = $_POST['type'];
       $name = $_POST['name'];
       
       
       $sql = "INSERT INTO doanthe (type , name )
       VALUES ('$type', '$name') ";
        mysqli_query($conn, $sql);

       

        header("location: Doan_the.php");
    }
    
       
?>
